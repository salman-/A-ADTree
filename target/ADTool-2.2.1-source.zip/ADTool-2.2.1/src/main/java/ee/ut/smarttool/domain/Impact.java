package ee.ut.smarttool.domain;


public class Impact {
	String impact;
	String description;

    public void setImpact(String impact) {
        this.impact = impact;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImpact() {
        return impact;
    }

    public String getDescription() {
        return description;
    }

}
