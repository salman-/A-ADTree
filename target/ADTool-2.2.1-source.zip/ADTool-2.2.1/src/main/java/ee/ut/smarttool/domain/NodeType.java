package ee.ut.smarttool.domain;

public enum NodeType {
	AttackNode,CountermeasureNode
}
