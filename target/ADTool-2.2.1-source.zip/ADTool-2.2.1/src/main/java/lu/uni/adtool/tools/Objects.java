package lu.uni.adtool.tools;

public class Objects {
  @SuppressWarnings("unchecked")
  public static <T> T cast(final Object target) {
    return (T) target;
  }
}
