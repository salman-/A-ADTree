package ee.ut.smarttool.DB;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ThreatAgentTest {
	ThreatAgent ta;
	@Before
	public void setUp() {
		 ta=new ThreatAgent();
	}
	
	@Test
	public void testInsertVulnerability() throws Exception {
		int res = ta.insertThreatAgent("Computer","MSc", "Zero", "StepStone");
		assertEquals(1, res);
	}

	@Test
	public void testUpdateAsset() throws Exception {
		int res = ta.insertThreatAgent("Computer","Phd", "Infinite", "StepStone|Intellectual");
		assertEquals(1, res);
	}

}
